=== Count Post Views ===
Contributors: tuanva
Donate link: 
Tags: count views, post views, views
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple to install and get your count post views. Show count views by using function `tamhuyet_count()` or `tamhuyet_count($post_id)`

== Description ==

install and get your count post views.

1. Upload plugin to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place echo `<?php echo tamhuyet_count(); ?>` or echo `tamhuyet_count($post_id)`  in your templates. With `$post_id` is ID of the Post your want

== Installation ==

1. Upload plugin to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place echo `tamhuyet_count()` or echo `tamhuyet_count($post_id)`  in your templates. With `$post_id` is ID of the Post your want

== Frequently asked questions ==



== Screenshots ==



== Changelog ==



== Upgrade notice ==
